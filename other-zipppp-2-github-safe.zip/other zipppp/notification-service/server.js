const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("Notification Service running 🚀");
});

app.listen(5004, () => {
  console.log("Notification Service running on 5004");
});