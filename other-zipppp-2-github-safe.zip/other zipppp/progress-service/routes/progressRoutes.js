const express = require("express");
const { getProgress, markLessonComplete, unmarkLesson } = require("../store");

const router = express.Router();

router.post("/complete", (req, res) => {
  const { userId, courseId, lessonId } = req.body || {};
  if (!userId || !courseId || !lessonId) {
    return res.status(400).json({ message: "userId, courseId, and lessonId are required" });
  }
  const updated = markLessonComplete(userId, courseId, lessonId);
  res.json({ message: "Lesson marked complete", ...updated });
});

router.post("/uncomplete", (req, res) => {
  const { userId, courseId, lessonId } = req.body || {};
  if (!userId || !courseId || !lessonId) {
    return res.status(400).json({ message: "userId, courseId, and lessonId are required" });
  }
  const updated = unmarkLesson(userId, courseId, lessonId);
  res.json({ message: "Lesson unmarked", ...updated });
});

router.get("/:userId", (req, res) => {
  const { userId } = req.params;
  if (!userId) {
    return res.status(400).json({ message: "userId required" });
  }
  res.json(getProgress(userId));
});

module.exports = router;
