/** In-memory progress: userId -> { courses: { courseId: { lessons: Set, updatedAt } } } */

const data = new Map();

function key(userId) {
  return String(userId);
}

function getUserRecord(userId) {
  const k = key(userId);
  if (!data.has(k)) {
    data.set(k, { courses: {} });
  }
  return data.get(k);
}

function getProgress(userId) {
  const rec = getUserRecord(userId);
  const byCourse = {};
  for (const [courseId, meta] of Object.entries(rec.courses)) {
    byCourse[courseId] = {
      completedLessonIds: [...meta.lessons],
      updatedAt: meta.updatedAt,
    };
  }
  return { userId: key(userId), byCourse };
}

function markLessonComplete(userId, courseId, lessonId) {
  const rec = getUserRecord(userId);
  if (!rec.courses[courseId]) {
    rec.courses[courseId] = { lessons: new Set(), updatedAt: new Date().toISOString() };
  }
  const c = rec.courses[courseId];
  c.lessons.add(String(lessonId));
  c.updatedAt = new Date().toISOString();
  return getProgress(userId);
}

function unmarkLesson(userId, courseId, lessonId) {
  const rec = getUserRecord(userId);
  const c = rec.courses[courseId];
  if (c?.lessons) {
    c.lessons.delete(String(lessonId));
    c.updatedAt = new Date().toISOString();
  }
  return getProgress(userId);
}

module.exports = { getProgress, markLessonComplete, unmarkLesson };
