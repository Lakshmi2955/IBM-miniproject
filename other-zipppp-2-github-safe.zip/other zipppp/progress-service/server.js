const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const progressRoutes = require("./routes/progressRoutes");

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

function landingHtml(port) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>DigiLearn · Progress API</title>
  <style>
    :root { --bg:#0c1210; --card:#152019; --text:#e6f4ec; --muted:#8aa699; --a:#34d399; }
    * { box-sizing: border-box; }
    body { margin:0; min-height:100vh; font-family:system-ui,sans-serif; background:radial-gradient(100% 70% at 80% -10%,#064e3b 0%,var(--bg) 50%); color:var(--text); }
    .wrap { max-width:720px; margin:0 auto; padding:48px 24px 64px; }
    h1 { font-size:1.75rem; font-weight:700; letter-spacing:-0.03em; margin:0 0 8px; }
    .sub { color:var(--muted); margin:0 0 28px; line-height:1.5; }
    .grid { display:grid; gap:12px; }
    a.card { display:block; padding:16px 18px; border-radius:14px; background:var(--card); border:1px solid rgba(255,255,255,.08); text-decoration:none; color:inherit; transition:transform .15s,border-color .2s; }
    a.card:hover { transform:translateY(-2px); border-color:rgba(52,211,153,.45); }
    a.card strong { display:block; font-size:1rem; margin-bottom:4px; color:var(--a); }
    a.card span { font-size:.85rem; color:var(--muted); }
    code { font-size:.8rem; background:rgba(255,255,255,.06); padding:2px 6px; border-radius:6px; }
    footer { margin-top:40px; font-size:.8rem; color:var(--muted); }
  </style>
</head>
<body>
  <div class="wrap">
    <h1>Progress service</h1>
    <p class="sub">Stores lesson completion per user (in-memory for demos) · port <code>${port}</code></p>
    <div class="grid">
      <a class="card" href="/api/progress/demo-user"><strong>GET /api/progress/:userId</strong><span>Snapshot of completed lessons</span></a>
      <a class="card" href="#"><strong>POST /api/progress/complete</strong><span>JSON body: userId, courseId, lessonId</span></a>
    </div>
    <footer>Use the DigiLearn app to POST from the browser via the API gateway.</footer>
  </div>
</body>
</html>`;
}

app.get("/", (req, res) => {
  res.type("html").send(landingHtml(process.env.PORT || 5003));
});

app.use("/api/progress", progressRoutes);

const PORT = process.env.PORT || 5003;
app.listen(PORT, () => {
  console.log(`Progress Service running on port ${PORT}`);
});
