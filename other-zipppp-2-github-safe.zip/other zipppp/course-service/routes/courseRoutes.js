const express = require("express");
const { COURSES, listCourses, getCourse } = require("../data/catalog");

const router = express.Router();

router.get("/meta", (req, res) => {
  const categories = [...new Set(COURSES.map((c) => c.category))];
  const totalLessons = COURSES.reduce((n, c) => n + c.lessons.length, 0);
  res.json({
    service: "digilearn-courses",
    version: "1.2.0",
    status: "ok",
    totalCourses: COURSES.length,
    totalLessons,
    categories,
    updated: new Date().toISOString(),
  });
});

router.get("/health", (req, res) => {
  res.json({ ok: true, uptime: process.uptime(), service: "courses" });
});

function sendCourseList(req, res) {
  const category = req.query.category;
  let items = listCourses();
  if (category && category !== "all") {
    items = items.filter((c) => c.category === category);
  }
  res.json({
    courses: items,
    meta: {
      count: items.length,
      filter: category || "all",
    },
  });
}

router.get("/", sendCourseList);

router.get("/:courseId", (req, res) => {
  const course = getCourse(req.params.courseId);
  if (!course) {
    return res.status(404).json({ message: "Course not found" });
  }
  res.json({ course });
});

module.exports = router;
