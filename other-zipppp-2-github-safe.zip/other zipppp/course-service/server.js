const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const courseRoutes = require("./routes/courseRoutes");

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

function landingHtml(port) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>DigiLearn · Course API</title>
  <style>
    :root { --bg:#0f0b14; --card:#1a1424; --text:#e8e4ef; --muted:#9b92ad; --a:#a78bfa; --b:#22d3ee; }
    * { box-sizing: border-box; }
    body { margin:0; min-height:100vh; font-family:system-ui,sans-serif; background:radial-gradient(120% 80% at 50% -20%,#2e1064 0%,var(--bg) 55%); color:var(--text); }
    .wrap { max-width:720px; margin:0 auto; padding:48px 24px 64px; }
    h1 { font-size:1.75rem; font-weight:700; letter-spacing:-0.03em; margin:0 0 8px; }
    .sub { color:var(--muted); margin:0 0 28px; line-height:1.5; }
    .grid { display:grid; gap:12px; }
    a.card { display:block; padding:16px 18px; border-radius:14px; background:var(--card); border:1px solid rgba(255,255,255,.08); text-decoration:none; color:inherit; transition:transform .15s,border-color .2s; }
    a.card:hover { transform:translateY(-2px); border-color:rgba(167,139,250,.45); }
    .card strong { display:block; font-size:1rem; margin-bottom:4px; color:var(--a); }
    .card span { font-size:.85rem; color:var(--muted); }
    code { font-size:.8rem; background:rgba(255,255,255,.06); padding:2px 6px; border-radius:6px; }
    footer { margin-top:40px; font-size:.8rem; color:var(--muted); }
  </style>
</head>
<body>
  <div class="wrap">
    <h1>Course service</h1>
    <p class="sub">DigiLearn catalog JSON API · port <code>${port}</code></p>
    <div class="grid">
      <a class="card" href="/api/courses/meta"><strong>GET /api/courses/meta</strong><span>Catalog stats, categories, version</span></a>
      <a class="card" href="/api/courses"><strong>GET /api/courses</strong><span>List all courses (optional ?category=…)</span></a>
      <a class="card" href="/api/courses/digital-foundations"><strong>GET /api/courses/:id</strong><span>Full course + lessons + key points</span></a>
      <a class="card" href="/api/courses/health"><strong>GET /api/courses/health</strong><span>Lightweight health check</span></a>
    </div>
    <footer>Proxied in production via API gateway at <code>/api/courses/*</code></footer>
  </div>
</body>
</html>`;
}

app.get("/", (req, res) => {
  res.type("html").send(landingHtml(process.env.PORT || 5012));
});

app.use("/api/courses", courseRoutes);

/** Default 5012 — port 5002 is often used by other local apps (e.g. another “market” service). */
const PORT = process.env.PORT || 5012;
app.listen(PORT, () => {
  console.log(`Course Service running on port ${PORT}`);
});
