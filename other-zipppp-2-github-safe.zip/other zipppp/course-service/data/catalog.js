/** In-app catalog: digital literacy core + extra learning paths */

const COURSES = [
  {
    id: "digital-foundations",
    title: "Digital Foundations",
    category: "Digital literacy",
    level: "Beginner",
    durationEstimate: "3 h",
    description:
      "Devices, accounts, and everyday digital confidence—perfect if you are starting out.",
    lessons: [
      {
        id: "df-1",
        title: "What is a computer and mobile OS?",
        durationMins: 12,
        summary: "Hardware basics, touch vs keyboard, and keeping software updated.",
      },
      {
        id: "df-2",
        title: "Creating and securing accounts",
        durationMins: 18,
        summary: "Strong passwords, two-factor basics, and recovery options.",
      },
      {
        id: "df-3",
        title: "Files, folders, and cloud storage",
        durationMins: 15,
        summary: "Organising documents and when to use cloud vs local storage.",
      },
      {
        id: "df-4",
        title: "Getting help safely",
        durationMins: 10,
        summary: "Official support channels and avoiding scams.",
      },
    ],
  },
  {
    id: "online-safety",
    title: "Staying Safe Online",
    category: "Digital literacy",
    level: "Beginner",
    durationEstimate: "2.5 h",
    description:
      "Privacy, phishing, and healthy habits so you can browse and message with less risk.",
    lessons: [
      {
        id: "os-1",
        title: "Understanding privacy settings",
        durationMins: 14,
        summary: "Profiles, location data, and who can see what you share.",
      },
      {
        id: "os-2",
        title: "Spotting phishing and scams",
        durationMins: 20,
        summary: "Fake links, urgency tricks, and verifying senders.",
      },
      {
        id: "os-3",
        title: "Kids, elders, and family safety",
        durationMins: 16,
        summary: "Screen time, parental controls, and respectful communication.",
      },
    ],
  },
  {
    id: "office-productivity",
    title: "Documents & Spreadsheets",
    category: "Office & productivity",
    level: "Beginner",
    durationEstimate: "4 h",
    description:
      "Create clear documents and simple budgets using common office tools.",
    lessons: [
      {
        id: "op-1",
        title: "Word processors: structure and sharing",
        durationMins: 22,
        summary: "Headings, lists, exporting PDFs, and collaboration links.",
      },
      {
        id: "op-2",
        title: "Spreadsheets for budgets and lists",
        durationMins: 25,
        summary: "Rows, formulas intro, and printing or sharing safely.",
      },
      {
        id: "op-3",
        title: "Presentations that stay readable",
        durationMins: 18,
        summary: "Less text on slides, contrast, and presenting on video calls.",
      },
    ],
  },
  {
    id: "email-messaging",
    title: "Email & Messaging Essentials",
    category: "Communication",
    level: "Beginner",
    durationEstimate: "2 h",
    description:
      "Professional email tone, attachments, and group chats without overwhelm.",
    lessons: [
      {
        id: "em-1",
        title: "Inbox habits that scale",
        durationMins: 12,
        summary: "Subject lines, CC/BCC, and unsubscribing cleanly.",
      },
      {
        id: "em-2",
        title: "Chat apps: threads, mute, and etiquette",
        durationMins: 15,
        summary: "When to call vs message and managing notifications.",
      },
    ],
  },
  {
    id: "creative-basics",
    title: "Creative Tools Basics",
    category: "Creative & media",
    level: "Beginner",
    durationEstimate: "3 h",
    description:
      "Resize images, simple graphics, and accessible captions for social posts.",
    lessons: [
      {
        id: "cb-1",
        title: "Images: crop, compress, and formats",
        durationMins: 16,
        summary: "JPEG vs PNG, resolution, and respecting copyright.",
      },
      {
        id: "cb-2",
        title: "Short video and captions",
        durationMins: 20,
        summary: "Vertical vs horizontal, subtitles, and file size tips.",
      },
      {
        id: "cb-3",
        title: "Accessible posts",
        durationMins: 14,
        summary: "Alt text, colour contrast, and plain language.",
      },
    ],
  },
  {
    id: "career-digital",
    title: "Digital Skills for Work",
    category: "Career & growth",
    level: "Intermediate",
    durationEstimate: "3.5 h",
    description:
      "CVs online, interview video calls, and professional profiles beyond this platform.",
    lessons: [
      {
        id: "cd-1",
        title: "Your professional profile",
        durationMins: 18,
        summary: "Photo, headline, and skills employers scan first.",
      },
      {
        id: "cd-2",
        title: "Video interviews",
        durationMins: 20,
        summary: "Lighting, audio, backups, and sharing your screen safely.",
      },
      {
        id: "cd-3",
        title: "Continuous learning",
        durationMins: 12,
        summary: "Setting goals and using bookmarks and calendars.",
      },
    ],
  },
];

/** Rich copy per course: outcomes, tags, longer overview */
const BOOST = {
  "digital-foundations": {
    outcomes: [
      "Name the main parts of a device and what an operating system does.",
      "Create accounts with strong passwords and optional two-factor sign-in.",
      "Organise files and choose cloud vs local storage for everyday tasks.",
    ],
    tags: ["Devices", "Accounts", "Files & cloud"],
    skillsYoullGain: [
      "Safer sign-in habits",
      "Clear folder structure for documents",
      "Knowing when to update software",
    ],
    longDescription:
      "Start from zero or refresh the basics: phones, laptops, updates, and where your files live. Each lesson is short on purpose so you can practise the same day.",
    /** Optional: intro video (replace with your own playlist or lesson link) */
    youtubeUrl: "https://www.youtube.com/watch?v=tpIctyqH29Q",
    youtubeLabel: "Crash Course Computer Science: what is a computer? (YouTube)",
  },
  "online-safety": {
    outcomes: [
      "Adjust privacy settings with a simple checklist.",
      "Recognise phishing patterns and verify who really sent a message.",
      "Support family members with age-appropriate safety habits.",
    ],
    tags: ["Privacy", "Scams", "Family"],
    skillsYoullGain: [
      "Fewer risky clicks",
      "Calmer conversations about screen time",
      "A personal safety routine you can repeat",
    ],
    longDescription:
      "Build habits that scale: less noise, fewer traps, and clearer boundaries for yourself and people you care about.",
  },
  "office-productivity": {
    outcomes: [
      "Structure readable documents and export them for sharing.",
      "Build a simple spreadsheet for budgets or lists.",
      "Design slides that stay legible on any screen.",
    ],
    tags: ["Documents", "Sheets", "Slides"],
    skillsYoullGain: [
      "Professional formatting",
      "Basic formulas and tables",
      "Presenting clearly on video calls",
    ],
    longDescription:
      "Office-style skills without vendor lock-in: ideas apply to common word processors, spreadsheets, and presentation tools.",
  },
  "email-messaging": {
    outcomes: [
      "Write clear subjects and use CC/BCC appropriately.",
      "Tame notifications and choose the right channel for the message.",
      "Keep attachments and links easy to scan and safe to open.",
    ],
    tags: ["Email", "Chat", "Etiquette"],
    skillsYoullGain: [
      "Faster, clearer email",
      "Less chat fatigue",
      "Polite, direct professional tone",
    ],
    longDescription:
      "Communication overload is common—these lessons focus on clarity, boundaries, and habits that save time.",
  },
  "creative-basics": {
    outcomes: [
      "Pick image formats and sizes for web and social posts.",
      "Add captions and subtitles people can actually read.",
      "Publish posts that work better for more people (accessibility).",
    ],
    tags: ["Images", "Video", "Accessibility"],
    skillsYoullGain: [
      "Crop and export without losing quality",
      "Shorter, clearer captions",
      "Alt text and contrast basics",
    ],
    longDescription:
      "Creative confidence for non-designers: good enough visuals, respectful reuse, and posts that look intentional.",
  },
  "career-digital": {
    outcomes: [
      "Shape a profile that matches how recruiters skim online.",
      "Run smoother video interviews with better audio and lighting.",
      "Plan ongoing learning without burning out.",
    ],
    tags: ["Profile", "Interviews", "Growth"],
    skillsYoullGain: [
      "Stronger first impression online",
      "Screen-share and backup plans",
      "Habit stacking for skills",
    ],
    longDescription:
      "Bridge classroom learning and the job market: polish how you show up digitally before and during interviews.",
  },
};

function enrichCatalog() {
  const practiceHints = [
    "Re-read the lesson summary and write one action for tomorrow.",
    "Try the steps on a practice file or demo account first.",
    "Teach the idea to someone else in one minute—clarity test.",
  ];
  for (const c of COURSES) {
    Object.assign(c, BOOST[c.id] || {});
    if (!c.longDescription) {
      c.longDescription = `${c.description} Lessons mix explanation with small actions you can repeat.`;
    }
    let i = 0;
    for (const lesson of c.lessons || []) {
      lesson.keyPoints = [
        lesson.summary,
        practiceHints[i % practiceHints.length],
        "Estimated effort in one sitting: about " + lesson.durationMins + " minutes.",
      ];
      i += 1;
    }
  }
}

enrichCatalog();

function listCourses() {
  return COURSES.map((c) => ({
    id: c.id,
    title: c.title,
    category: c.category,
    level: c.level,
    durationEstimate: c.durationEstimate,
    description: c.description,
    longDescription: c.longDescription,
    lessonCount: c.lessons?.length ?? 0,
    outcomes: c.outcomes,
    tags: c.tags,
    skillsYoullGain: c.skillsYoullGain,
    youtubeUrl: c.youtubeUrl || null,
    youtubeLabel: c.youtubeLabel || null,
  }));
}

function getCourse(courseId) {
  const course = COURSES.find((c) => c.id === courseId);
  if (!course) return null;
  const copy = JSON.parse(JSON.stringify(course));
  if (!Array.isArray(copy.lessons)) {
    copy.lessons = [];
  }
  return copy;
}

module.exports = { COURSES, listCourses, getCourse };
