const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const axios = require("axios");

dotenv.config();

const app = express();

const corsOrigin = process.env.CORS_ORIGIN
  ? process.env.CORS_ORIGIN.split(",").map((o) => o.trim())
  : true;
app.use(
  cors({
    origin: corsOrigin,
  })
);
app.use(express.json());

/** Avoid double /api when env is e.g. http://host:5002/api */
function normalizeUpstreamBase(raw) {
  if (!raw || typeof raw !== "string") return raw;
  return raw.trim().replace(/\/+$/, "").replace(/\/api$/i, "");
}

/** Express may expose path differently behind mounts; keep full /api/... path */
function upstreamPathOnly(req) {
  let path = "";
  const fromOriginal = req.originalUrl && String(req.originalUrl).split("?")[0];
  if (fromOriginal && fromOriginal.startsWith("/")) {
    path = fromOriginal;
  } else {
    const base = req.baseUrl || "";
    const rest = req.url || "/";
    path = `${base}${rest === "/" ? "" : rest}`.replace(/\/{2,}/g, "/");
    if (!path.startsWith("/")) path = `/${path}`;
  }
  if (path.length > 1 && path.endsWith("/")) {
    path = path.slice(0, -1);
  }
  return path;
}

function friendlyUpstreamName(baseEnvKey) {
  const map = {
    USER_SERVICE_URL: "user service",
    COURSE_SERVICE_URL: "course service",
    PROGRESS_SERVICE_URL: "progress service",
    NOTIFICATION_SERVICE_URL: "notification service",
  };
  return map[baseEnvKey] || baseEnvKey;
}

function proxyTo(baseEnvKey) {
  return async (req, res) => {
    const base = process.env[baseEnvKey];
    if (!base) {
      return res.status(503).json({
        message: `${friendlyUpstreamName(baseEnvKey)} is not configured (set ${baseEnvKey}).`,
        code: "UPSTREAM_NOT_CONFIGURED",
      });
    }
    try {
      const cleanBase = normalizeUpstreamBase(base);
      const pathOnly = upstreamPathOnly(req);
      const url = `${cleanBase}${pathOnly}`;
      const response = await axios({
        method: req.method,
        url,
        data: req.body,
        params: req.query,
        headers: { "Content-Type": "application/json" },
        timeout: 25000,
        validateStatus: () => true,
      });
      const payload = response.data;
      const ct = response.headers["content-type"] || "";
      if (typeof payload === "string" && ct.includes("html")) {
        return res.status(response.status).type("html").send(payload);
      }
      if (typeof payload === "object" && payload !== null) {
        return res.status(response.status).json(payload);
      }
      return res.status(response.status).send(payload ?? "");
    } catch (error) {
      const code = error.code;
      if (code === "ECONNREFUSED" || code === "ENOTFOUND" || code === "ETIMEDOUT") {
        return res.status(503).json({
          message: `Cannot reach ${friendlyUpstreamName(baseEnvKey)}. Start it locally or check ${baseEnvKey}.`,
          code: "UPSTREAM_UNAVAILABLE",
          detail: error.message,
        });
      }
      res
        .status(error.response?.status || 500)
        .json(
          error.response?.data || {
            message: error.message || "Gateway error",
            code: "GATEWAY_ERROR",
          }
        );
    }
  };
}

/* Regex mounts: Express 5 path matching can miss plain "/api/foo" for some clients; prefix match is reliable */
app.use(/^\/api\/users(?:\/|$)/, proxyTo("USER_SERVICE_URL"));
app.use(/^\/api\/courses(?:\/|$)/, proxyTo("COURSE_SERVICE_URL"));
app.use(/^\/api\/progress(?:\/|$)/, proxyTo("PROGRESS_SERVICE_URL"));
app.use(/^\/api\/notifications(?:\/|$)/, proxyTo("NOTIFICATION_SERVICE_URL"));

app.get("/", (req, res) => {
  res.send("API Gateway is running");
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`API Gateway running on port ${PORT}`);
  if (!process.env.USER_SERVICE_URL) {
    console.warn("USER_SERVICE_URL is not set; /api/users will return 503.");
  }
  if (!process.env.COURSE_SERVICE_URL) {
    console.warn("COURSE_SERVICE_URL is not set; /api/courses will return 503.");
  }
  if (!process.env.PROGRESS_SERVICE_URL) {
    console.warn("PROGRESS_SERVICE_URL is not set; /api/progress will return 503.");
  }
});