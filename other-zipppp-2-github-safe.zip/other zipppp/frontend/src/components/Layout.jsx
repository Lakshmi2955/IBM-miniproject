import { Link, NavLink } from "react-router-dom";

export default function Layout({ children }) {
  return (
    <div className="app-shell">
      <div className="app-bg" aria-hidden="true" />
      <header className="site-header">
        <Link to="/" className="brand">
          <span className="brand-mark" />
          DigiLearn
        </Link>
        <nav className="site-nav" aria-label="Main">
          <NavLink
            to="/"
            className={({ isActive }) => `nav-link${isActive ? " active" : ""}`}
            end
          >
            Home
          </NavLink>
          <NavLink
            to="/login"
            className={({ isActive }) => `nav-link${isActive ? " active" : ""}`}
          >
            Login
          </NavLink>
          <NavLink
            to="/register"
            className={({ isActive }) => `nav-link${isActive ? " active" : ""}`}
          >
            Register
          </NavLink>
          <NavLink
            to="/courses"
            className={({ isActive }) => `nav-link${isActive ? " active" : ""}`}
          >
            Courses
          </NavLink>
          <NavLink
            to="/progress"
            className={({ isActive }) => `nav-link${isActive ? " active" : ""}`}
          >
            Progress
          </NavLink>
          <NavLink
            to="/dashboard"
            className={({ isActive }) =>
              `nav-link nav-link--accent${isActive ? " active" : ""}`
            }
          >
            Dashboard
          </NavLink>
        </nav>
      </header>
      <main className="site-main">{children}</main>
      <footer className="site-footer">
        <span>Digital Literacy Platform</span>
        <span className="footer-dot" aria-hidden="true" />
        <span>Learn at your pace</span>
      </footer>
    </div>
  );
}
