import { Routes, Route, Link } from "react-router-dom";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Courses from "./pages/Courses";
import CourseDetail from "./pages/CourseDetail";
import Progress from "./pages/Progress";

function Home() {
  return (
    <div className="home">
      <section className="hero">
        <p className="hero-eyebrow">Welcome</p>
        <h1 className="hero-title">
          Learn digital skills
          <span className="hero-title-gradient"> with confidence</span>
        </h1>
        <p className="hero-lead">
          Courses, progress tracking, and a calm space to build literacy—whether
          you are just starting or levelling up.
        </p>
        <div className="hero-actions">
          <Link to="/register" className="btn btn-primary">
            Get started
          </Link>
          <Link to="/login" className="btn btn-ghost">
            Sign in
          </Link>
          <Link to="/courses" className="btn btn-ghost">
            Browse courses
          </Link>
        </div>
      </section>

      <section className="feature-grid" aria-label="Highlights">
        <article className="feature-card">
          <div className="feature-icon" aria-hidden="true">
            ◆
          </div>
          <h3>Structured paths</h3>
          <p>Step-by-step modules so you always know what comes next.</p>
        </article>
        <article className="feature-card">
          <div className="feature-icon feature-icon--b" aria-hidden="true">
            ◇
          </div>
          <h3>Track progress</h3>
          <p>See what you have completed and pick up where you left off.</p>
        </article>
        <article className="feature-card">
          <div className="feature-icon feature-icon--c" aria-hidden="true">
            ✦
          </div>
          <h3>Your dashboard</h3>
          <p>One place for your profile and learning snapshot after you sign in.</p>
        </article>
      </section>
    </div>
  );
}

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/courses/:courseId" element={<CourseDetail />} />
        <Route path="/progress" element={<Progress />} />
      </Routes>
    </Layout>
  );
}

export default App;
