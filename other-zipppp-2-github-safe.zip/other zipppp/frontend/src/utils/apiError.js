/** User-facing message from axios / gateway errors */
export function formatApiError(error) {
  if (error?.response?.data?.message) {
    return error.response.data.message;
  }
  if (error?.code === "ERR_NETWORK" || error?.message === "Network Error") {
    return "Network error — is the API gateway running? In dev, use Vite proxy (npm run dev) and start services on ports 5050, 5002.";
  }
  if (error?.code === "ECONNABORTED") {
    return "Request timed out. Try again.";
  }
  return error?.message || "Something went wrong.";
}
