import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";
import { formatApiError } from "../utils/apiError";

function Dashboard() {
  const [user, setUser] = useState(null);
  const [summary, setSummary] = useState({
    courseCount: 0,
    overallPct: 0,
    started: 0,
    loading: true,
    error: "",
  });

  useEffect(() => {
    const raw = localStorage.getItem("user");
    if (raw) {
      try {
        setUser(JSON.parse(raw));
      } catch {
        setUser(null);
      }
    }
  }, []);

  useEffect(() => {
    if (!user?.id) {
      setSummary((s) => ({ ...s, loading: false }));
      return;
    }
    const userId = String(user.id);
    let cancelled = false;
    async function load() {
      setSummary((s) => ({ ...s, loading: true, error: "" }));
      try {
        const [cRes, pRes] = await Promise.all([
          API.get("/api/courses"),
          API.get(`/api/progress/${userId}`),
        ]);
        if (cancelled) return;
        const courses = cRes.data.courses || [];
        const byCourse = pRes.data.byCourse || {};
        const rows = courses.map((c) => {
          const block = byCourse[c.id];
          const done = block?.completedLessonIds?.length || 0;
          const total = c.lessonCount || 0;
          return { done, total };
        });
        const totalLessons = rows.reduce((acc, r) => acc + r.total, 0);
        const totalDone = rows.reduce((acc, r) => acc + r.done, 0);
        const overallPct = totalLessons
          ? Math.round((totalDone / totalLessons) * 100)
          : 0;
        const started = rows.filter((r) => r.done > 0).length;
        setSummary({
          courseCount: courses.length,
          overallPct,
          started,
          loading: false,
          error: "",
        });
      } catch (e) {
        if (!cancelled) {
          setSummary({
            courseCount: 0,
            overallPct: 0,
            started: 0,
            loading: false,
            error: formatApiError(e),
          });
        }
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, [user]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "/login";
  };

  if (!user) {
    return (
      <div className="dashboard-page">
        <div className="empty-state">
          <div className="empty-state-icon" aria-hidden="true">
            ◈
          </div>
          <h2 className="empty-state-title">You are not signed in</h2>
          <p className="empty-state-text">Sign in to view your dashboard and saved progress.</p>
          <Link className="btn btn-primary" to="/login">
            Go to sign in
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="dashboard-page">
      <section className="dash-welcome">
        <div className="dash-welcome-text">
          <p className="dash-eyebrow">Your space</p>
          <h2 className="dash-title">Hello, {user.name || user.email?.split("@")[0] || "learner"}</h2>
          <p className="dash-email">{user.email}</p>
        </div>
        <button type="button" className="btn btn-ghost" onClick={handleLogout}>
          Sign out
        </button>
      </section>

      <div className="dash-quick-links" role="navigation" aria-label="Learning">
        <Link className="dash-tile" to="/courses">
          <span className="dash-tile-title">Courses</span>
          <span className="dash-tile-desc">Browse the full catalog</span>
        </Link>
        <Link className="dash-tile" to="/progress">
          <span className="dash-tile-title">Progress</span>
          <span className="dash-tile-desc">See completion by course</span>
        </Link>
      </div>

      <div className="dash-stats" role="region" aria-label="Overview">
        <div className="stat-card">
          <span className="stat-label">Account</span>
          <span className="stat-value">Active</span>
        </div>
        <div className="stat-card">
          <span className="stat-label">Catalog</span>
          <span className="stat-value">
            {summary.loading ? "…" : summary.error ? "—" : summary.courseCount}
          </span>
        </div>
        <div className="stat-card">
          <span className="stat-label">Overall progress</span>
          <span className="stat-value">
            {summary.loading ? "…" : summary.error ? "—" : `${summary.overallPct}%`}
          </span>
        </div>
        <div className="stat-card">
          <span className="stat-label">Courses started</span>
          <span className="stat-value">
            {summary.loading ? "…" : summary.error ? "—" : summary.started}
          </span>
        </div>
      </div>

      {summary.error ? (
        <p className="auth-message auth-message--error" style={{ marginBottom: "16px" }}>
          {summary.error}
        </p>
      ) : null}

      <section className="dash-panel">
        <h3 className="dash-panel-title">Next steps</h3>
        <ul className="dash-list">
          <li>
            Open <Link to="/courses">Courses</Link> to explore digital literacy and extra topics.
          </li>
          <li>
            Mark lessons done inside a course—progress syncs via the <Link to="/progress">Progress</Link> page.
          </li>
          <li>Data is stored in the progress service (in-memory on the server until you add a database).</li>
        </ul>
      </section>
    </div>
  );
}

export default Dashboard;
