import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";
import { formatApiError } from "../utils/apiError";

const CATEGORIES = [
  { value: "all", label: "All topics" },
  { value: "Digital literacy", label: "Digital literacy" },
  { value: "Office & productivity", label: "Office & productivity" },
  { value: "Communication", label: "Communication" },
  { value: "Creative & media", label: "Creative & media" },
  { value: "Career & growth", label: "Career & growth" },
];

function Courses() {
  const [courses, setCourses] = useState([]);
  const [listMeta, setListMeta] = useState(null);
  const [category, setCategory] = useState("all");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [retryToken, setRetryToken] = useState(0);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      setError("");
      try {
        const config =
          category === "all" ? {} : { params: { category } };
        const res = await API.get("/api/courses", config);
        if (cancelled) return;
        const data = res.data || {};
        setCourses(Array.isArray(data.courses) ? data.courses : []);
        setListMeta(data.meta || null);
      } catch (e) {
        if (!cancelled) {
          setCourses([]);
          setListMeta(null);
          setError(formatApiError(e));
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, [category, retryToken]);

  return (
    <div className="learn-page">
      <header className="learn-header">
        <p className="dash-eyebrow">Catalog</p>
        <h1 className="learn-title">Courses to learn</h1>
        <p className="learn-lead">
          Core digital literacy plus office tools, communication, media, and career skills. Each
          course lists outcomes, tags, and lesson counts. Sign in to track completion lesson by
          lesson.
        </p>
        {listMeta ? (
          <p className="learn-muted learn-meta-line">
            Showing <strong>{listMeta.count}</strong> course{listMeta.count === 1 ? "" : "s"}
            {listMeta.filter && listMeta.filter !== "all"
              ? ` · Topic: ${listMeta.filter}`
              : ""}
          </p>
        ) : null}
      </header>

      <div className="filter-chips" role="tablist" aria-label="Filter by topic">
        {CATEGORIES.map((c) => (
          <button
            key={c.value}
            type="button"
            role="tab"
            aria-selected={category === c.value}
            className={`filter-chip${category === c.value ? " filter-chip--active" : ""}`}
            onClick={() => setCategory(c.value)}
          >
            {c.label}
          </button>
        ))}
      </div>

      {loading ? <p className="learn-muted">Loading courses…</p> : null}
      {error ? (
        <div className="course-error-panel">
          <p className="auth-message auth-message--error">{error}</p>
          <p className="learn-muted course-error-hint">
            Tip: run <code>api-gateway</code> (port 5050), <code>course-service</code> (5002), and
            this app with <code>npm run dev</code> so <code>/api</code> proxies correctly.
          </p>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => setRetryToken((n) => n + 1)}
          >
            Retry
          </button>
        </div>
      ) : null}

      {!loading && !error && courses.length === 0 ? (
        <p className="learn-muted">No courses match this filter. Try “All topics”.</p>
      ) : null}

      {!loading && !error && courses.length > 0 ? (
        <div className="course-grid">
          {courses.map((c) => (
            <article key={c.id} className="course-card">
              <span className="course-card-badge">{c.category}</span>
              <h2 className="course-card-title">{c.title}</h2>
              <p className="course-card-meta">
                {c.level} · {c.durationEstimate} · {c.lessonCount} lessons
              </p>
              {c.youtubeUrl ? (
                <p className="course-card-video-hint">
                  <span className="course-card-video-icon" aria-hidden="true">
                    ▶
                  </span>
                  Includes a YouTube intro
                </p>
              ) : null}
              {c.tags?.length ? (
                <div className="tag-row" aria-label="Tags">
                  {c.tags.map((t) => (
                    <span key={t} className="tag-chip">
                      {t}
                    </span>
                  ))}
                </div>
              ) : null}
              <p className="course-card-desc">{c.description}</p>
              {c.outcomes?.length ? (
                <ul className="course-card-outcomes">
                  {c.outcomes.slice(0, 2).map((o, idx) => (
                    <li key={`${c.id}-o-${idx}`}>{o}</li>
                  ))}
                  {c.outcomes.length > 2 ? <li>+ {c.outcomes.length - 2} more outcomes in course…</li> : null}
                </ul>
              ) : null}
              <Link className="btn btn-primary course-card-cta" to={`/courses/${c.id}`}>
                Open course
              </Link>
            </article>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export default Courses;
