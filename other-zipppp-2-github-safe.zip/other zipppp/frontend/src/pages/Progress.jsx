import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";
import { useCurrentUser } from "../hooks/useCurrentUser";
import { formatApiError } from "../utils/apiError";

function Progress() {
  const { userId, isLoggedIn } = useCurrentUser();
  const [courses, setCourses] = useState([]);
  const [byCourse, setByCourse] = useState({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isLoggedIn) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    async function load() {
      setLoading(true);
      setError("");
      try {
        const [cRes, pRes] = await Promise.all([
          API.get("/api/courses"),
          API.get(`/api/progress/${userId}`),
        ]);
        if (cancelled) return;
        setCourses(cRes.data.courses || []);
        setByCourse(pRes.data.byCourse || {});
      } catch (e) {
        if (!cancelled) {
          setError(formatApiError(e));
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, [isLoggedIn, userId]);

  if (!isLoggedIn) {
    return (
      <div className="learn-page">
        <div className="empty-state">
          <div className="empty-state-icon" aria-hidden="true">
            ◇
          </div>
          <h2 className="empty-state-title">Sign in to see progress</h2>
          <p className="empty-state-text">
            Your completed lessons are stored per account on this device session.
          </p>
          <Link className="btn btn-primary" to="/login">
            Sign in
          </Link>
          <p className="auth-footer" style={{ marginTop: "16px" }}>
            <Link to="/courses">Browse courses</Link> without an account.
          </p>
        </div>
      </div>
    );
  }

  const rows = courses.map((c) => {
    const block = byCourse[c.id];
    const done = block?.completedLessonIds?.length || 0;
    const total = c.lessonCount || 0;
    const pct = total ? Math.round((done / total) * 100) : 0;
    return { ...c, done, total, pct };
  });

  const started = rows.filter((r) => r.done > 0);
  const totalLessons = rows.reduce((s, r) => s + r.total, 0);
  const totalDone = rows.reduce((s, r) => s + r.done, 0);
  const overall = totalLessons ? Math.round((totalDone / totalLessons) * 100) : 0;

  return (
    <div className="learn-page">
      <header className="learn-header">
        <p className="dash-eyebrow">Learning</p>
        <h1 className="learn-title">Your progress</h1>
        <p className="learn-lead">
          Overview of every catalog course and how many lessons you have completed.
        </p>
      </header>

      {loading ? <p className="learn-muted">Loading…</p> : null}
      {error ? <p className="auth-message auth-message--error">{error}</p> : null}

      {!loading && !error ? (
        <>
          <section className="progress-summary-cards" aria-label="Summary">
            <div className="stat-card stat-card--wide">
              <span className="stat-label">Overall completion</span>
              <span className="stat-value stat-value--large">{overall}%</span>
              <span className="stat-hint">Average across all courses in the catalog</span>
            </div>
            <div className="stat-card">
              <span className="stat-label">Courses started</span>
              <span className="stat-value">{started.length}</span>
            </div>
            <div className="stat-card">
              <span className="stat-label">In catalog</span>
              <span className="stat-value">{rows.length}</span>
            </div>
          </section>

          <ul className="progress-course-list">
            {rows.map((r) => (
              <li key={r.id} className="progress-course-row">
                <div className="progress-course-info">
                  <Link to={`/courses/${r.id}`} className="progress-course-link">
                    {r.title}
                  </Link>
                  <span className="course-card-meta">
                    {r.category} · {r.done}/{r.total} lessons
                  </span>
                </div>
                <div className="progress-bar-track progress-bar-track--inline">
                  <div className="progress-bar-fill" style={{ width: `${r.pct}%` }} />
                </div>
                <span className="progress-pct">{r.pct}%</span>
              </li>
            ))}
          </ul>

          <p className="auth-footer" style={{ marginTop: "24px" }}>
            <Link to="/courses">Explore more courses</Link>
          </p>
        </>
      ) : null}
    </div>
  );
}

export default Progress;
