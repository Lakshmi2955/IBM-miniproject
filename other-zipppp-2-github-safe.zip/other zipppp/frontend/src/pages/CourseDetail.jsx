import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import API from "../services/api";
import { useCurrentUser } from "../hooks/useCurrentUser";
import { formatApiError } from "../utils/apiError";
import { getYoutubeEmbedSrc } from "../utils/youtube";

function CourseDetail() {
  const { courseId } = useParams();
  const { userId, isLoggedIn } = useCurrentUser();
  const [course, setCourse] = useState(null);
  const [completed, setCompleted] = useState(new Set());
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function loadCourse() {
      setLoading(true);
      setError("");
      try {
        const res = await API.get(`/api/courses/${encodeURIComponent(courseId)}`);
        if (cancelled) return;
        const payload = res.data?.course ?? res.data;
        if (payload && typeof payload === "object" && payload.id) {
          setCourse(payload);
        } else {
          setCourse(null);
          setError("Course not found.");
        }
      } catch (e) {
        if (!cancelled) {
          setError(formatApiError(e));
          setCourse(null);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    loadCourse();
    return () => {
      cancelled = true;
    };
  }, [courseId]);

  useEffect(() => {
    if (!userId || !courseId) return;
    let cancelled = false;
    async function loadProgress() {
      try {
        const res = await API.get(`/api/progress/${userId}`);
        const block = res.data.byCourse?.[courseId];
        const ids = block?.completedLessonIds || [];
        if (!cancelled) setCompleted(new Set(ids));
      } catch {
        if (!cancelled) setCompleted(new Set());
      }
    }
    loadProgress();
    return () => {
      cancelled = true;
    };
  }, [userId, courseId]);

  async function toggleLesson(lessonId, isDone) {
    if (!userId) return;
    setBusyId(lessonId);
    setError("");
    try {
      if (isDone) {
        await API.post("/api/progress/uncomplete", {
          userId,
          courseId,
          lessonId,
        });
        setCompleted((prev) => {
          const next = new Set(prev);
          next.delete(lessonId);
          return next;
        });
      } else {
        await API.post("/api/progress/complete", {
          userId,
          courseId,
          lessonId,
        });
        setCompleted((prev) => new Set(prev).add(lessonId));
      }
    } catch (e) {
      setError(formatApiError(e));
    } finally {
      setBusyId(null);
    }
  }

  const lessons = Array.isArray(course?.lessons) ? course.lessons : [];
  const total = lessons.length;
  const doneCount = lessons.filter((l) => completed.has(l.id)).length;
  const pct = total ? Math.round((doneCount / total) * 100) : 0;
  const embedSrc = course?.youtubeUrl ? getYoutubeEmbedSrc(course.youtubeUrl) : null;

  if (loading) {
    return (
      <div className="learn-page">
        <p className="learn-muted">Loading course…</p>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="learn-page">
        <p className="auth-message auth-message--error">{error || "Not found."}</p>
        <Link to="/courses" className="btn btn-ghost">
          Back to courses
        </Link>
      </div>
    );
  }

  return (
    <div className="learn-page learn-page--narrow">
      <nav className="breadcrumb">
        <Link to="/courses">Courses</Link>
        <span aria-hidden="true"> / </span>
        <span>{course.title}</span>
      </nav>

      <header className="course-hero">
        <span className="course-card-badge">{course.category}</span>
        <h1 className="learn-title course-hero-title">{course.title}</h1>
        <p className="course-card-meta">
          {course.level} · {course.durationEstimate} · {lessons.length} lessons
        </p>
        <p className="learn-lead">{course.description}</p>
        {course.longDescription ? (
          <p className="course-long-desc">{course.longDescription}</p>
        ) : null}

        {course.outcomes?.length ? (
          <section className="course-info-block" aria-labelledby="outcomes-heading">
            <h2 id="outcomes-heading" className="course-info-heading">
              What you will learn
            </h2>
            <ul className="course-info-list">
              {course.outcomes.map((o, idx) => (
                <li key={`out-${idx}`}>{o}</li>
              ))}
            </ul>
          </section>
        ) : null}

        {course.skillsYoullGain?.length ? (
          <section className="course-info-block" aria-labelledby="skills-heading">
            <h2 id="skills-heading" className="course-info-heading">
              Skills you will practice
            </h2>
            <ul className="course-info-tags">
              {course.skillsYoullGain.map((s) => (
                <li key={s}>{s}</li>
              ))}
            </ul>
          </section>
        ) : null}

        {course.tags?.length ? (
          <div className="tag-row tag-row--hero" aria-label="Topics">
            {course.tags.map((t) => (
              <span key={t} className="tag-chip">
                {t}
              </span>
            ))}
          </div>
        ) : null}

        {course.youtubeUrl ? (
          <section className="course-video-section" aria-labelledby="video-heading">
            <h2 id="video-heading" className="course-info-heading">
              Recommended video
            </h2>
            <p className="course-video-note">
              {course.youtubeLabel ||
                "Supplementary video on YouTube (opens in a new tab)."}
            </p>
            {embedSrc ? (
              <div className="course-video-wrap">
                <iframe
                  title={course.youtubeLabel || "Course video"}
                  src={embedSrc}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="strict-origin-when-cross-origin"
                />
              </div>
            ) : null}
            <a
              className="btn btn-ghost course-youtube-link"
              href={course.youtubeUrl}
              target="_blank"
              rel="noopener noreferrer"
            >
              Open on YouTube
            </a>
          </section>
        ) : null}

        <div className="progress-block" aria-label="Course progress">
          <div className="progress-bar-track">
            <div
              className="progress-bar-fill"
              style={{ width: `${pct}%` }}
            />
          </div>
          <span className="progress-bar-label">
            {doneCount} of {total} lessons complete ({pct}%)
          </span>
        </div>

        {!isLoggedIn ? (
          <p className="course-hint">
            <Link to="/login">Sign in</Link> to save lesson completion on this device.
          </p>
        ) : null}
        {error ? <p className="auth-message auth-message--error">{error}</p> : null}
      </header>

      <ol className="lesson-list">
        {lessons.map((lesson, index) => {
          const isDone = completed.has(lesson.id);
          const busy = busyId === lesson.id;
          return (
            <li key={lesson.id} className={`lesson-item${isDone ? " lesson-item--done" : ""}`}>
              <div className="lesson-index">{index + 1}</div>
              <div className="lesson-body">
                <h3 className="lesson-title">{lesson.title}</h3>
                <p className="lesson-summary">{lesson.summary}</p>
                {lesson.keyPoints?.length ? (
                  <ul className="lesson-keypoints">
                    {lesson.keyPoints.map((kp, i) => (
                      <li key={`${lesson.id}-kp-${i}`}>{kp}</li>
                    ))}
                  </ul>
                ) : null}
                <span className="lesson-duration">{lesson.durationMins} min</span>
              </div>
              <div className="lesson-actions">
                {isLoggedIn ? (
                  <button
                    type="button"
                    className={`btn ${isDone ? "btn-ghost" : "btn-primary"}`}
                    disabled={busy}
                    onClick={() => toggleLesson(lesson.id, isDone)}
                  >
                    {busy ? "…" : isDone ? "Undo" : "Mark done"}
                  </button>
                ) : (
                  <span className="learn-muted">—</span>
                )}
              </div>
            </li>
          );
        })}
      </ol>

      <div className="course-footer-actions">
        <Link to="/courses" className="btn btn-ghost">
          All courses
        </Link>
        <Link to="/progress" className="btn btn-primary">
          View my progress
        </Link>
      </div>
    </div>
  );
}

export default CourseDetail;
