import axios from "axios";

/**
 * Normalize VITE_API_URL so requests like `/api/courses` do not become `/api/api/courses`
 * (common when the env var is set to `https://host.../api`).
 */
function normalizeApiBase(url) {
  if (!url || typeof url !== "string") return url;
  return url.trim().replace(/\/+$/, "").replace(/\/api$/i, "");
}

// Dev: empty baseURL + Vite proxy → /api hits gateway reliably.
// Prod: set VITE_API_URL to your gateway origin only (no trailing /api).
const baseURL = normalizeApiBase(
  import.meta.env.VITE_API_URL ||
    (import.meta.env.DEV ? "" : "http://localhost:5050")
);

const API = axios.create({
  baseURL,
  timeout: 30000,
});

export default API;
