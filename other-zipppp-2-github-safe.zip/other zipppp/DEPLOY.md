# Deploy DigiLearn

## 1. Backend (Render)

1. Push this project to GitHub (or GitLab / Bitbucket).
2. In [Render](https://render.com), create a **Blueprint** and connect the repo; select `render.yaml`, or create two **Web Services** manually using the same settings as the blueprint.
3. In the Render dashboard, set these **environment variables** for `digilearn-user`:
   - `MONGO_URI` — your MongoDB connection string
   - `JWT_SECRET` — a long random secret string
4. For `digilearn-gateway`, set:
   - `CORS_ORIGIN` — your frontend URL, e.g. `https://your-app.vercel.app` (no trailing slash). You can list several origins separated by commas.
5. The blueprint also deploys **course** and **progress** APIs; the gateway receives their URLs automatically. Wait until all services are **Live**, then copy the gateway URL (e.g. `https://digilearn-gateway.onrender.com`).

**Note:** Progress is stored in memory on the progress service and resets when that instance restarts or sleeps (fine for demos; add a database later for persistence).

Free-tier services sleep after inactivity; the first request after sleep can take ~30–60 seconds.

## 2. Frontend (Vercel)

1. In [Vercel](https://vercel.com), **Add New Project** and import the same repo.
2. Set **Root Directory** to `frontend`.
3. Under **Environment Variables**, add:
   - **Name:** `VITE_API_URL`  
   - **Value:** your gateway URL, e.g. `https://digilearn-gateway.onrender.com` (no trailing slash)
4. Deploy. Vercel will run `npm install` and `npm run build` automatically.

## 3. Finish CORS

After you know your final Vercel URL, ensure `CORS_ORIGIN` on the gateway includes exactly that origin (scheme + host, no path), then redeploy or restart the gateway service if needed.

## Local parity

Use `frontend/.env.local` (not committed) for local builds:

```bash
VITE_API_URL=http://localhost:5050
```
